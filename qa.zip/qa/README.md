# 88-AutoSignMachine

 联通挂机任务积分脚本
 
推荐使用github免费提供action机制执行脚本， 联通手厅签到用户请自行添加秘钥参数（https://github.com/你的用户名/88-AutoSignMachine/settings/secrets/actions 然后点击New repository secret）
ENABLE_UNICOM （填true）

sckey（service酱）

unicom_password（服务密码）

unicom_user（手机号）

unicom_appid（http://m.client.10010.com/mobileService/customer/getclientconfig.htm?appId= 开抓包 你再打开手厅就能找到了）

NOTIFY_SCKEY（service酱得key）

#多用户配置

https://github.com/你的用户名/88-AutoSignMachine/settings/secrets/actions 然后点击New repository secret

unicom_user2（手机号）

unicom_password2（服务密码）

unicom_appid2（http://m.client.10010.com/mobileService/customer/getclientconfig.htm?appId= 开抓包 你再打开手厅就能找到了或者共享主号的）